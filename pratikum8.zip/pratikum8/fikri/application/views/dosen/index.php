<div class="col-md-12">
 <h3>
 Daftar Dosen
 </h3>
 <table class="table" border="1">
 <thead>
 <tr>
 <th>id</th><th>nama</th><th>nidn</th><th>gender</th>
<th>tmp_lahir</th><th>tgl_lahir</th> <th>pendidikan</th>
 </tr>
 </thead>
 <tbody>
 <?php
 $nomor=1;
 foreach($list_dsn as $dsn){
 ?>
 <tr>
 <td><?=$nomor?></td>
 <td><?=$dsn->nama?></td>
 <td><?=$dsn->nidn?></td>
 <td><?=$dsn->gender?></td>
 <td><?=$dsn->tmp_lahir?></td>
 <td><?=$dsn->tgl_lahir?></td>
 <td><?=$dsn->pendidikan?></td>
 </tr>
 <?php
 $nomor++;
 }
 ?>
 </tbody>
 </table>
</div>