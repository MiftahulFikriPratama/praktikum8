<?php
class matakuliah_model extends CI_Model {
 // lengkapi
 public $nama;
 public $sks;
 public $kode;
}
?>