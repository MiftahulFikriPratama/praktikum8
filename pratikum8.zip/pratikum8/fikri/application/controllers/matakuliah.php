<?php
defined('BASEPATH') OR exit('No direct script access allowe
d');
class matakuliah extends CI_Controller {
 public function index()
 {
 $this->load->model('matakuliah_model', 'mtaklah');
 $this->mtaklah->nama='JK, PPKN, BD, BIG, KE, PW, UIUX, SP';
 $this->mtaklah->sks='jumlah sks 21';
 $this->mtaklah->kode='21';
 $list_mtaklah = [$this->mtaklah];
 $data['list_mtaklah']=$list_mtaklah;
 //$this->load->view('header');
 $this->load->view('matakuliah/index',$data);
 //$this->load->view('footer');
 }
}
?>